package test.automationFramework;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import test.pageObjects.Home_Page;

public class TestHome_Page {
	WebDriver driver;
	WebDriverWait wait;

	@BeforeTest
	@Parameters("browser")
	public void beforeSuite(String browser) throws Exception {
		if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else {
			throw new Exception("Browser is not correct");

		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.get("http://store.demoqa.com/");
	}

	@Test
	public void verifyTotalPrice() throws AWTException {
		wait.until(ExpectedConditions.elementToBeClickable(Home_Page
				.lnk_ProductCategory(driver)));
		Point coordinate = Home_Page.lnk_ProductCategory(driver).getLocation();
		Robot robot = new Robot();
		robot.mouseMove(
				(Home_Page.lnk_ProductCategory(driver).getSize().height / 2)
						+ coordinate.getX(),
				coordinate.getY()
						+ (Home_Page.lnk_ProductCategory(driver).getSize().width / 2));
		Home_Page.lnk_iPhones(driver).click();
		Home_Page.lnk_iPhones4S16GBSimFree(driver).click();
		float currentPrice = Float.parseFloat(Home_Page
				.txt_currentprice(driver).getText().replace("$", ""));
		Home_Page.btn_AddToCart(driver).click();
		robot.mouseMove(1, 1);
		wait.until(ExpectedConditions.elementToBeClickable(Home_Page
				.lnk_gotoCheckOut(driver)));
		Home_Page.lnk_gotoCheckOut(driver).click();
		Home_Page.btn_Continue(driver).click();
		wait.until(ExpectedConditions.elementToBeClickable(Home_Page
				.btn_Calucate(driver)));
		Select dropdown = new Select(Home_Page.drp_Country(driver));
		dropdown.selectByValue("IN");
		Home_Page.btn_Calucate(driver).click();
		float shippingCost = Float.parseFloat(Home_Page.txt_Shipping(driver)
				.getText().replace("$", ""));
		float taxcost = Float.parseFloat(Home_Page.txt_Tax(driver).getText()
				.replace("$", ""));
		float totalCost = Float.parseFloat(Home_Page.txt_TotalPrice(driver)
				.getText().replace("$", ""));
		Assert.assertEquals(shippingCost + taxcost + currentPrice, totalCost);
	}

	@Test
	public void verifyEmptyCartMessage() throws AWTException {
		wait.until(ExpectedConditions.elementToBeClickable(Home_Page
				.lnk_ProductCategory(driver)));
		Point coordinate = Home_Page.lnk_ProductCategory(driver).getLocation();
		Robot robot = new Robot();
		robot.mouseMove(
				(Home_Page.lnk_ProductCategory(driver).getSize().height / 2)
						+ coordinate.getX(),
				coordinate.getY()
						+ (Home_Page.lnk_ProductCategory(driver).getSize().width / 2));
		Home_Page.lnk_iPhones(driver).click();
		Home_Page.lnk_iPhones4S16GBSimFree(driver).click();
		Home_Page.btn_AddToCart(driver).click();
		robot.mouseMove(1, 1);
		wait.until(ExpectedConditions.elementToBeClickable(Home_Page
				.lnk_gotoCheckOut(driver)));
		Home_Page.lnk_gotoCheckOut(driver).click();
		Home_Page.btn_Remove(driver).click();
		Assert.assertEquals(Home_Page.div_Message(driver).getText(), "Oops, there is nothing in your cart.");
	}
	@AfterSuite
	public void closeAll(){
		driver.quit();
	}
}
