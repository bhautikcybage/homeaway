package test.automationFramework;

import java.awt.AWTException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

public class APITest {

	@Test
	public void verifyShortDistance() throws AWTException, JSONException {
		try {
			URL url = new URL(
					"https://api.data.gov/nrel/alt-fuel-stations/v1/nearest.json?api_key=S4DeculXeg4ywunbQ20uhSswpTpseghD4Yzg2Pba&location=Austin+TX");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException(" HTTP error code : "
						+ conn.getResponseCode());
			}

			Scanner scan = new Scanner(url.openStream());
			String entireResponse = new String();
			while (scan.hasNext())
				entireResponse += scan.nextLine();

			scan.close();

			JSONObject obj = new JSONObject(entireResponse);
			// String responseCode = obj.getString("status");

			JSONArray arr = obj.getJSONArray("fuel_stations");
			for (int i = 0; i < arr.length(); i++) {
				String placeid = arr.getJSONObject(i).getString("distance");
				System.out.println("Place id : " + placeid);

			}

			conn.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}
