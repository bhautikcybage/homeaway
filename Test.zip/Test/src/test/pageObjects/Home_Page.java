package test.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Home_Page {
	private static WebElement element = null;

	public static WebElement lnk_ProductCategory(WebDriver driver) {
		element = driver.findElement(By.linkText("Product Category"));
		return element;

	}

	public static WebElement lnk_iPhones(WebDriver driver) {
		element = driver.findElement(By.linkText("iPhones"));
		return element;

	}

	public static WebElement lnk_iPhones4S16GBSimFree(WebDriver driver) {
		element = driver.findElement(By
				.linkText("Apple iPhone 4S 16GB SIM-Free � Black"));
		return element;
	}

	public static WebElement txt_currentprice(WebDriver driver) {
		element = driver.findElement(By.cssSelector("span.currentprice"));
		return element;
	}

	public static WebElement btn_AddToCart(WebDriver driver) {
		element = driver.findElement(By.cssSelector("input.wpsc_buy_button"));
		return element;
	}

	public static WebElement lnk_gotoCheckOut(WebDriver driver) {
		element = driver.findElement(By.linkText("Go to Checkout"));
		return element;
	}

	public static WebElement btn_Continue(WebDriver driver) {
		element = driver.findElement(By.linkText("Continue"));
		return element;
	}

	public static WebElement drp_Country(WebDriver driver) {
		element = driver.findElement(By.id("current_country"));
		return element;
	}

	public static WebElement btn_Calucate(WebDriver driver) {
		element = driver.findElement(By.name("wpsc_submit_zipcode"));
		return element;
	}

	public static WebElement txt_Shipping(WebDriver driver) {
		element = driver
				.findElement(By
						.cssSelector("#wpsc_shopping_cart_container > form > div.review.group > table > tbody > tr.total_price.total_shipping > td:nth-child(2) > span > span"));
		return element;
	}

	public static WebElement txt_Tax(WebDriver driver) {
		element = driver
				.findElement(By
						.cssSelector("#wpsc_shopping_cart_container > form > div.review.group > table > tbody > tr.total_price.total_tax > td:nth-child(2) > span > span"));
		return element;
	}

	public static WebElement txt_TotalPrice(WebDriver driver) {
		element = driver.findElement(By.cssSelector("#checkout_total > span"));
		return element;
	}
	public static WebElement btn_Remove(WebDriver driver) {
		element = driver.findElement(By.cssSelector("#checkout_page_container > div.slide1 > table > tbody > tr.product_row.product_row_0.alt > td.wpsc_product_remove.wpsc_product_remove_0 > form > input[type='submit']:nth-child(4)"));
		return element;
	}
	public static WebElement div_Message(WebDriver driver) {
		element = driver.findElement(By.cssSelector("div.entry-content"));
		return element;
	}
	
}
